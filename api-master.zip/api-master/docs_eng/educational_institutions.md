# Educational institutions

> Attention! The values in the directories may change at any time. Do not address them directly.

You can get the following information for educational institutions:
* [Basic information about educational institutions](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-educational-institutions-dictionary)
* [List of faculties of the educational institution](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-faculties)
